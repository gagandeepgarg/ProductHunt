import { Component, OnInit } from '@angular/core';
import{ProductService} from '../shared/product.service';
import{CartService} from '../shared/cart.service';
import{ICart} from '../shared/cart.model'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products:any;
  cartItems:any;
  constructor(private productService:ProductService,private cartService:CartService) { }

  ngOnInit() {
    this.cartService.getCartItemsData().subscribe((data) =>
    {
      this.cartItems = data;
      this.productService.getProducts().subscribe((data)=>{
        this.products = data;
        this.products.forEach(product => {
          if(this.cartItems.find(cartItem=>cartItem.itemId === product.itemId))
            product.addedTocart= false;
          else
            product.addedTocart=true;
        });
      });
    });   
    
  }

  addToCart(product){
    this.cartService.addToCart(product);
    this.products.find(prod=>prod.itemId == product.itemId).addedTocart=false;
  }

}
