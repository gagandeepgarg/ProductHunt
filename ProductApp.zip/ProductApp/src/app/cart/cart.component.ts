import { Component, OnInit } from '@angular/core';
import{CartService} from '../shared/cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  constructor(private cartService:CartService) { }

  ngOnInit() {
    this.cartService.getCartItems();
  }
  
  getTotalPrice(){
    var price=0;
    this.cartService.cartItems.forEach(cartItem => {
      price+= parseInt(cartItem.price);
    });
    return price;
  }
  deleteFromCart(item){
    this.cartService.deleteCartItem(item.itemId);
  }
}
