import { Component,OnInit } from '@angular/core'
import {Router} from '@angular/router'
import{CartService} from '../shared/cart.service';
@Component({
  selector: 'nav-bar',
  templateUrl:'./navbar.component.html',
  styles: [`
    .numberCircle{
      border-radius: 50%;
      width: 10px;
      height: 5px;
      padding: 4px;
      background: #fff;
      color: #666;
      text-align: center;
    }
    .nav-icon { height:85px; width:150px;}
    .a:active { background-color: grey; }
    .a:hover { background-color: blue;}
  `],
})
export class NavBarComponent implements OnInit{
  username:string="";
  constructor(private cartService:CartService){
    this.username="Guest";
  }
  ngOnInit(){
  }

  getCartProductCount(){
    return this.cartService.getCartItemCount();
  }
}
