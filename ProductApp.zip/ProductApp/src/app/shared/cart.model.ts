export  interface ICart {
    itemId: number
    name?: string
    price?: number
    imageUrl?: string
    addedTocart?:boolean
}
