import { Injectable } from '@angular/core';
import{HttpClient,HttpHeaders } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class CartService {
  cartItems:any=[];
  constructor(private http:HttpClient ) {
    this.getCartItems();
   }
   getCartItemCount(){
     return this.cartItems.length;
   }
   getCartItemsData(){
    return this.http.get('http://localhost:8808/api/cart');
  }
   getCartItems(){
    this.http.get('http://localhost:8808/api/cart').subscribe((data)=>{
      this.cartItems = data;
    });
   }
   
   deleteCartItem(Id){
     var itemId =parseInt(Id)
     const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type':  'application/json'})
    };
     this.http.post('http://localhost:8808/api/cart/delete/'+ itemId,httpOptions).subscribe(data=>{
      this.getCartItems();
     });
   }

   addToCart(product){
     console.log(product);
    const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type':  'application/json'})
    };
    this.http.post('http://localhost:8808/api/cart/',JSON.stringify(product), httpOptions)
    .subscribe(data=>{
      this.cartItems.push(product);
      this.getCartItems();
    });

   }
}
