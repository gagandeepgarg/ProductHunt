var express = require('express');

var env = process.env.NODE_ENV = process.env.NODE_ENV || 'development';
var  port = process.env.PORT || 8808

var app = express();

require('./expressConfig')(app);
//require('./routes')(app);

productRouter=require('./Routes/productRoutes')();
cartRouter=require('./Routes/cartRoutes')();

app.use('/api/product',productRouter);
app.use('/api/cart',cartRouter);
require('./database/products')();
app.listen(port);
console.log('Listening on port ' + port + '...');