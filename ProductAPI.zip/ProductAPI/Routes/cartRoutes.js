var express = require('express');

var Cart=require('../models/cartModel');

var routes=function(){
    var cartRouter=express.Router();
    cartRouter.route('/')
    .get(function(req,res){
        Cart.find({},function(err,cart){
            res.send(cart);
        });
    })
    .post(function(req,res){
        var cartItem=req.body;
        var query = {};
        query.itemId=cartItem.itemId;
        Cart.find(query,function(err,cart){
            if (err) {
                res.status(500).send(err);
            }
            else if(cart && cart.length>0){
                res.status(400).send({"Message":"Item Id already exists"});
            }
            else{
                let cart = new Cart(cartItem);
                cart.save((err, createdcart) => {  
                    if (err) {
                        res.status(500).send(err);
                    }
                    res.status(200).send(createdcart);
                });
            }
        });                
    });
    cartRouter.route('/delete/:Id')
    .post(function(req,res){
        var query = {};
        query.itemId= parseInt(req.params.Id);
        Cart.findOne(query,function(err,cartItem){
            if(cartItem){
                Cart.remove(query,function(err, item) {
                    if(err)
                        res.status(500).send(err);
                    else
                        res.status(200).send({"Message":"Item deleted"});                    }
                );
            }
        });
    });
    return cartRouter;
}
module.exports=routes;