var express = require('express');

var Product=require('../models/productModel');

var routes=function(){
    var productRouter=express.Router();
    productRouter.route('/')
    .post(function(req,res){
        var product=new Product(req.body);
        product.save(function(err) {
            if (err)
                    return res.send(err);
            else
                res.send(product.name +' Added');
        });
    })
    .get(function(req,res){
        Product.find(function(err,product){
            if(err)
                res.status(500).send(err);
            else
                res.json(product);
        });   
    });
    
    productRouter.route('/:itemId')
    .get(function(req,res){
        var query = {};
        query.itemId=  +req.params.itemId;
        Product.findOne(query, function(err, product) {
            if(err)
                res.status(500).send(err);
            else
                res.send(product);
        });
    })
    return productRouter;    
}

module.exports=routes;