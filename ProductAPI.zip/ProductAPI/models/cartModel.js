var mongoose=require('mongoose'),
Schema=mongoose.Schema;

var cartModel=new Schema({ 
                itemId:{type:Number},
                name:{type:String},
                imageUrl:{type:String},
                price:{type:Number},
            });
module.exports=mongoose.model('cart',cartModel);