var Product=require('../models/productModel');
const products=[
	{
	"itemId":1,
        "name":"Product1",
        "imageUrl":"Product1.jpg",
        "price":500
	},{
	"itemId":2,
        "name":"Product2",
        "imageUrl":"Product2.jpg",
        "price":600
	},{
	"itemId":3,
        "name":"Product3",
        "imageUrl":"Product3.jpg",
        "price":500
	},{
	"itemId":4,
        "name":"Product4",
        "imageUrl":"Product4.jpg",
        "price":1500
	},{
	"itemId":5,
        "name":"Product5",
        "imageUrl":"Product5.jpg",
        "price":500
	},{
	"itemId":6,
        "name":"Product6",
        "imageUrl":"Product6.jpg",
        "price":1000
	},{
	"itemId":7,
        "name":"Product7",
        "imageUrl":"Product7.jpg",
        "price":700
	},{
	"itemId":8,
        "name":"Product8",
        "imageUrl":"Product8.jpg",
        "price":1800
	},{
	"itemId":9,
        "name":"Product9",
        "imageUrl":"Product9.jpg",
        "price":500
	},{
	"itemId":10,
        "name":"Product10",
        "imageUrl":"Product10.jpg",
        "price":1500
	},{
	"itemId":11,
        "name":"Product11",
        "imageUrl":"Product11.jpg",
        "price":400
	},
	{
	"itemId":12,
        "name":"Product12",
        "imageUrl":"Product12.jpg",
        "price":1400
	},
]

var dbSeeder= function(){
Product.find({}, function(err, product) {
        if(product && product.length>=0){
                console.log('data is live');
        }
        else{
                for (product of products) {
                        var newProduct = new Product(product);
                        newProduct.save();
                }
                console.log('Data seeded successfully');
        }
      });
}

module.exports=dbSeeder;